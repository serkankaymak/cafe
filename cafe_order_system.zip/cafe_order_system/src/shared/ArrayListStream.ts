import { Predicate, Func, Action } from "./listeners";

class ItemWrapper<T> {
    item: T | null;
    index: number;
    next: ItemWrapper<T> | null = null;
    previous: ItemWrapper<T> | null = null;

    constructor(item: T | null, index: number) {
        this.item = item;
        this.index = index;
    }
}

export default class ArrayListStream<T> {
    private innerList: (T | null)[] = [];

    static fromObject<T>(obj: T): ArrayListStream<T> {
        const arrayListStream = new ArrayListStream<T>();
        arrayListStream.add(obj);
        return arrayListStream;
    }

    static fromList<T>(list: T[]): ArrayListStream<T> {
        const arrayListStream = new ArrayListStream<T>();
        list.forEach((item) => arrayListStream.add(item));
        return arrayListStream;
    }

    static fromArrayListStream<T>(arrayListStream: ArrayListStream<T>): ArrayListStream<T> {
        const newList = new ArrayListStream<T>();
        arrayListStream.innerList.forEach((item) => newList.add(item));
        return newList;
    }

    add(item: T | null): void {
        this.innerList.push(item);
    }

    addAll(items: (T | null)[]): void {
        this.innerList.push(...items);
    }

    findIndex(predicate: Predicate<T>): number {
        return this.innerList.findIndex(predicate);
    }

    getFromIndex(index: number): T | null {
        return this.innerList[index];
    }

    selectWithIndex<R>(func: Func<ItemWrapper<T>, R>): ArrayListStream<R> {
        const newList = new ArrayListStream<R>();
        this.innerList.forEach((item, index) => {
            const wrapper = new ItemWrapper(item, index);
            const transformedItem = func(wrapper);
            newList.add(transformedItem);
        });
        return newList;
    }

    foreachExecuteThisWithIndex(action: Action<ItemWrapper<T>>): void {
        this.innerList.forEach((item, index) => {
            const wrapper = new ItemWrapper(item, index);
            action(wrapper);
        });
    }

    foreachExecuteThis(action: Action<T>): void {
        this.innerList.forEach((item) => {
            if (item !== null) action(item);
        });
    }

    getLinkedItems(): ArrayListStream<ItemWrapper<T>> {
        const linkedList = new ArrayListStream<ItemWrapper<T>>();
        this.innerList.forEach((item, index) => {
            linkedList.add(new ItemWrapper(item, index));
        });

        linkedList.innerList.forEach((wrapper, index) => {
            const current = wrapper as ItemWrapper<T>;
            if (index > 0) {
                const previous = linkedList.innerList[index - 1] as ItemWrapper<T>;
                current.previous = previous;
                previous.next = current;
            }
            if (index < linkedList.innerList.length - 1) {
                const next = linkedList.innerList[index + 1] as ItemWrapper<T>;
                current.next = next;
            }
        });

        return linkedList;
    }

    wheree(predicate: Predicate<T>): ArrayListStream<T> {
        const newList = new ArrayListStream<T>();
        this.innerList.forEach((item) => {
            if (predicate(item)) newList.add(item);
        });
        return newList;
    }

    getUniqueList<R>(func: Func<T, R>): ArrayListStream<T> {
        const uniqueValues = new Set<R>();
        const uniqueList = new ArrayListStream<T>();
        this.innerList.forEach((item) => {
            if (item !== null) {
                const value = func(item);
                if (!uniqueValues.has(value)) {
                    uniqueValues.add(value);
                    uniqueList.add(item);
                }
            }
        });
        return uniqueList;
    }


    countForThisMatch(predicate: Predicate<T>): number {
        return this.innerList.filter(predicate).length;
    }

    isAllMatch(predicate: Predicate<T>): boolean {
        return this.innerList.every(predicate);
    }

    isThereAllSame<R>(func: Func<T, R>): boolean {
        if (this.innerList.length <= 1) return true;
        const firstValue = func(this.innerList[0]);
        return this.innerList.every((item) => item !== null && func(item) === firstValue);
    }

    convertToPlainStringArray(func: Func<T, string>): string {
        return this.innerList.map((item) => (item !== null ? func(item) : "")).join(", ");
    }

    firstOrDefault(predicate: Predicate<T>): T | null {
        return this.innerList.find(predicate) || null;
    }
}
