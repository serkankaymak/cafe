class Logcat {

    static Debug(message: any | null): void { console.debug(message); }
    static Error(message: any | null): void { console.error(message); }
    static Info(message: any | null): void { console.info(message); }

}
