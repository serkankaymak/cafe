"use client";
import React, { useState } from "react";
import HeaderComponent from "./components/Header";
import { Box } from "@mui/material";
import LeftDrawer from "./components/LeftDrawer";
import "./styles/layout.css";

interface HomePageState {
    isThemeDark: boolean;
    isLeftDrawerOpen: boolean;
}

interface HomePageStateProps { }

const HomePage: React.FC<HomePageStateProps> = () => {
    const [state, setState] = useState<HomePageState>({
        isThemeDark: false,
        isLeftDrawerOpen: false,
    });

    return (
        <div>
            <HeaderComponent
                onMenuItemClick={(e) => {
                    console.log(e);
                    setState((prevState) => ({
                        ...prevState,
                        isLeftDrawerOpen: !prevState.isLeftDrawerOpen,
                    }));
                }}
                onMessageClick={null}
                onNotificationClick={null}
                onProfileClick={null}
                onThemeChangerClick={() => {
                    console.log("Theme changed:", state.isThemeDark, "to", !state.isThemeDark);
                    setState((prevState) => ({
                        ...prevState,
                        isThemeDark: !prevState.isThemeDark, // Doğru kullanım
                    }));
                }}
                messageCountProp={10}
                notificationCountProp={13}
                isUserLoggedInProp={true}
                isDarkModeOnProp={state.isThemeDark}
                className="bg-slate-100 p-14"  >
            </HeaderComponent>

            {/* Add your component here */}
            <input className="leftDrawerCheckboxController hidden" checked={state.isLeftDrawerOpen && state.isLeftDrawerOpen} type="checkbox" />
            <div className="content-wrapper">
                <LeftDrawer isOpenInitial={state.isLeftDrawerOpen} onClose={function (): void {
                    console.log("Drawer closed");
                    setState((prevState) => ({ ...prevState, isLeftDrawerOpen: !prevState.isLeftDrawerOpen }));
                }} />
            </div>

        </div>
    );
};

export default HomePage;
