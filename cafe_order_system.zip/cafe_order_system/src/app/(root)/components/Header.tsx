"use client"
import * as React from 'react';
import AppBar from '@mui/material/AppBar';
import Box from '@mui/material/Box';
import Toolbar from '@mui/material/Toolbar';
import IconButton from '@mui/material/IconButton';
import Typography from '@mui/material/Typography';
import Badge from '@mui/material/Badge';
import MenuIcon from '@mui/icons-material/Menu';
import AccountCircle from '@mui/icons-material/AccountCircle';
import MailIcon from '@mui/icons-material/Mail';
import NotificationsIcon from '@mui/icons-material/Notifications';
import MoreIcon from '@mui/icons-material/MoreVert';
import { useState } from 'react';
import { Action } from '@/shared/listeners';
import { LightModeOutlined, LoginRounded, NightlightRoundOutlined } from '@mui/icons-material';

interface HeaderProps {
    className?: string; // Opsiyonel className prop
    onMenuItemClick: Action<HTMLElement> | null;
    onMessageClick: Action<HTMLElement> | null;
    onNotificationClick: Action<HTMLElement> | null;
    onProfileClick: Action<HTMLElement> | null;
    onThemeChangerClick: Action<HTMLElement> | null;
    messageCountProp: number;
    notificationCountProp: number;
    isUserLoggedInProp?: boolean;
    isDarkModeOnProp?: boolean;
}

interface HeaderState {
    messageCount: number | null;
    notificationCount: number | null;
    isUserLoggedIn?: boolean;
    isDarkModeOn?: boolean;
}

const HeaderComponent: React.FC<HeaderProps> = React.memo(
    ({
        onMenuItemClick,
        onMessageClick,
        onNotificationClick,
        onProfileClick,
        onThemeChangerClick,
        messageCountProp,
        notificationCountProp,
        isUserLoggedInProp,
        isDarkModeOnProp,
        className,
    }) => {
        const [state, setState] = useState<HeaderState>({
            messageCount: messageCountProp ?? 1,
            notificationCount: notificationCountProp ?? 0,
            isUserLoggedIn: isUserLoggedInProp ?? false,
            isDarkModeOn: isDarkModeOnProp ?? false,
        });

        // Props değiştiğinde state'i güncelle
        React.useEffect(() => {
            setState((prevState) => ({
                ...prevState, isDarkModeOn: isDarkModeOnProp ?? prevState.isDarkModeOn,
            }));
        }, [isDarkModeOnProp]);


        const getThemeButton = (): React.ReactNode => (
            <Box>
                {state.isDarkModeOn ? (
                    <IconButton
                        onClick={(event: React.MouseEvent<HTMLButtonElement>) => {
                            if (onThemeChangerClick) { onThemeChangerClick(event.currentTarget); }
                        }}
                        size="large"
                        edge="end"
                        color="inherit"
                        aria-label="toggle to light mode"
                    >
                        <LightModeOutlined />
                    </IconButton>
                ) : (
                    <IconButton
                        onClick={(event: React.MouseEvent<HTMLButtonElement>) => {
                            if (onThemeChangerClick) { onThemeChangerClick(event.currentTarget); }
                        }}
                        size="large"
                        edge="end"
                        color="inherit"
                        aria-label="toggle to dark mode"
                    >
                        <NightlightRoundOutlined />
                    </IconButton>
                )}
            </Box>
        );

        return (
            <AppBar position="static" className={`p-2 ${className || ""}`}>
                <Toolbar className="flex flex-row content-between justify-between">
                    <IconButton
                        onClick={(event: React.MouseEvent<HTMLButtonElement>) => {
                            if (onMenuItemClick) { onMenuItemClick(event.currentTarget); }
                        }}
                        size="large"
                        edge="start"
                        color="inherit"
                        aria-label="open drawer"
                    >
                        <MenuIcon />
                    </IconButton>
                    <Typography variant="h6" noWrap component="div"></Typography>
                    <Box>
                        <Box className="sm:block hidden">
                            <Box className="flex gap-2">
                                <IconButton size="large" color="inherit">
                                    <Badge badgeContent={state.messageCount} color="error">
                                        <MailIcon />
                                    </Badge>
                                </IconButton>
                                <IconButton
                                    size="large"
                                    color="inherit"
                                    aria-label={`show ${state.notificationCount || 0} new notifications`}
                                >
                                    <Badge badgeContent={state.notificationCount} color="error">
                                        <NotificationsIcon />
                                    </Badge>
                                </IconButton>
                                <IconButton size="large" edge="end" color="inherit">
                                    {state.isUserLoggedIn ? <AccountCircle /> : <LoginRounded />}
                                </IconButton>
                                {getThemeButton()}
                            </Box>
                        </Box>
                    </Box>
                </Toolbar>
            </AppBar>
        );
    }
);

export default HeaderComponent;