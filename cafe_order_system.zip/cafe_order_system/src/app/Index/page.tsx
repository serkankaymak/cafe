
import React, { useState } from 'react';

interface IndexProps {
    title: string | null;
}

interface IndexState {
}

const IndexPage: React.FC<IndexProps> = React.memo(
    ({ title = null }) => {
        const [state, setState] = useState<IndexState>({
        });

        const changeStates = () => {
            setState((prevState) => ({
                ...prevState,
            }));
        };

        return (
            <div>
                hello from index
            </div>
        );
    }
);

export default IndexPage;
