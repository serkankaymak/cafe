// src/contexts/AuthContext.tsx
'use client'; // Bu bileşeni Client Component olarak işaretler

import React, { createContext, useState, useEffect, ReactNode } from 'react';
import axios from 'axios';
import { useRouter } from 'next/navigation'; // next/navigation paketini kullanın

// Kullanıcı bilgilerini tanımlayan arayüz
interface User {
    id: number;
    username: string;
    email: string;
    isBanned: boolean;
    // Diğer kullanıcı bilgileri...
}

// AuthContext'in sunduğu değerleri tanımlayan arayüz
interface AuthContextType {
    user: User | null;
    login: (username: string, password: string) => Promise<void>;
    logout: () => void;
}

// AuthContext'i oluşturma
export const AuthContext = createContext<AuthContextType>({
    user: null,
    login: async () => { },
    logout: () => { },
});

interface AuthProviderProps {
    children: ReactNode;
}

// AuthProvider bileşeni
export const AuthProvider: React.FC<AuthProviderProps> = ({ children }) => {
    const [user, setUser] = useState<User | null>(null);
    const router = useRouter();

    useEffect(() => {
        // Sayfa yüklendiğinde token varsa kullanıcı bilgilerini al
        const token = localStorage.getItem('token');
        if (token) {
            axios.get('/api/user', {
                headers: {
                    Authorization: `Bearer ${token}`,
                },
            })
                .then(response => {
                    setUser(response.data);
                })
                .catch(error => {
                    console.error('User fetch error:', error);
                    setUser(null);
                    localStorage.removeItem('token'); // Token geçersizse temizle
                });
        }
    }, []);

    const login = async (username: string, password: string) => {
        try {
            const response = await axios.post('/api/auth/login', { username, password });
            const { token, user } = response.data;
            localStorage.setItem('token', token);
            setUser(user);
            router.push('/'); // Giriş sonrası yönlendirme
        } catch (error: any) {
            console.error('Login error:', error.response?.data?.message || error.message);
            throw new Error(error.response?.data?.message || 'Login failed');
        }
    };

    const logout = () => {
        localStorage.removeItem('token');
        setUser(null);
        router.push('/login');
    };

    return (
        <AuthContext.Provider value={{ user, login, logout }}>
            {children}
        </AuthContext.Provider>
    );
};
